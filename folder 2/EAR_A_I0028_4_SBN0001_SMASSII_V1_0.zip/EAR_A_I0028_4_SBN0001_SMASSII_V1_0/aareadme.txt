PDS_VERSION_ID                     = PDS3                                     
RECORD_TYPE                        = STREAM                                   
                                                                              
OBJECT                             = TEXT                                     
   PUBLICATION_DATE                = 2005-02-13  /* Label Last Generated */   
   NOTE                            = "Volume information"                     
END_OBJECT                         = TEXT                                     
                                                                              
END                                                                           
                                                                              
PDS OLAF Data Set Volume                                                      
                                                                              
Peer Review: PSI Asteroid Review, 2003-09-25                                  
Discipline Node: Small Bodies                                                 
Peer Review Contact: Neese, Carol                                             
                                                                              
Data Set Name: Small Main-belt Asteroid Spectroscopic Survey, Phase II        
Submitter: Bus, Schelte                                                       
                                                                              
The data and associated PDS labels and catalog files are organized into the   
        following directories:                                                
                                                                              
catalog - containing PDS catalog files for the data set, observatories,       
        instruments, facilities, and a listing of references.                 
                                                                              
data - containing the data files and their corresponding labels.              
                                                                              
document - containing ancillary documents and files related to this data set  
        including the file sent to Abstract Data Service (ADS).               
                                                                              
index - containing the PDS required index and its label.                      
